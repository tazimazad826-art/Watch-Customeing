// checkout-validator.js
// Validates cart totals, discounts, and free gifts before checkout
console.log('[CV] Checkout Validator loaded');

class CheckoutValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
    this.cartData = null;
    this.init();
  }

  init() {
    console.log('[CV] Initializing Checkout Validator');
    this.loadCartData();
    this.setupValidation();
  }

  loadCartData() {
    // Load cart data for validation
    fetch('/cart.js')
      .then(response => response.json())
      .then(cart => {
        console.log('[CV] Cart data loaded:', cart);
        this.cartData = cart;
        this.validateCart();
      })
      .catch(error => {
        console.error('[CV] Error loading cart data:', error);
      });
  }

  validateCart() {
    console.log('[CV] Starting cart validation');
    this.errors = [];
    this.warnings = [];

    if (!this.cartData) {
      this.errors.push('Unable to load cart data');
      return;
    }

    // Validate configurator price overrides
    this.validateConfiguratorPrices();
    
    // Validate discount application
    this.validateDiscounts();
    
    // Validate free gifts
    this.validateFreeGifts();
    
    // Validate total calculation
    this.validateTotalCalculation();

    this.showValidationResults();
  }

  validateConfiguratorPrices() {
    console.log('[CV] Validating configurator prices');
    
    this.cartData.items.forEach((item, index) => {
      const hasPriceOverride = item.properties && item.properties._wc_price_override_cents;
      
      if (hasPriceOverride) {
        const overrideCents = parseInt(item.properties._wc_price_override_cents);
        const expectedTotal = overrideCents * item.quantity;
        const actualLineTotal = item.line_price;
        
        if (expectedTotal !== actualLineTotal) {
          this.errors.push(`Price override mismatch for item ${index + 1}: expected ${expectedTotal}c, got ${actualLineTotal}c`);
        } else {
          console.log(`[CV] ✓ Configurator price validated for item ${index + 1}`);
        }
      }
    });
  }

  validateDiscounts() {
    console.log('[CV] Validating discounts');
    
    // Check for applied discounts
    const hasCartDiscounts = this.cartData.cart_level_discount_applications && 
                           this.cartData.cart_level_discount_applications.length > 0;
    
    const hasItemDiscounts = this.cartData.items.some(item => 
      item.discounts && item.discounts.length > 0
    );

    if (!hasCartDiscounts && !hasItemDiscounts) {
      // Check if any items have discount properties
      const hasDiscountProperties = this.cartData.items.some(item => 
        item.properties && this.hasDiscountProperties(item.properties)
      );
      
      if (hasDiscountProperties) {
        this.warnings.push('Discount properties detected but not applied to cart total');
      }
    } else {
      console.log('[CV] ✓ Discounts found and applied');
    }
  }

  hasDiscountProperties(properties) {
    const discountProps = ['discount_code', 'coupon', 'promotion', 'sale_price'];
    return Object.keys(properties).some(key => 
      discountProps.some(prop => key.toLowerCase().includes(prop.toLowerCase()))
    );
  }

  validateFreeGifts() {
    console.log('[CV] Validating free gifts');
    
    this.cartData.items.forEach((item, index) => {
      const hasFreeGiftProperty = item.properties && 
        (item.properties['Free Gift'] || 
         item.properties['free_gift'] ||
         item.properties['Is Free Gift']);
      
      if (hasFreeGiftProperty) {
        if (item.price > 0) {
          this.errors.push(`Item ${index + 1} marked as free gift but has non-zero price`);
        } else {
          console.log(`[CV] ✓ Free gift validated for item ${index + 1}`);
        }
      }
    });
  }

  validateTotalCalculation() {
    console.log('[CV] Validating total calculation');
    
    let calculatedSubtotal = 0;
    let calculatedDiscounts = 0;
    
    // Calculate expected totals
    this.cartData.items.forEach(item => {
      let itemTotal = item.line_price;
      
      // Apply price overrides
      if (item.properties && item.properties._wc_price_override_cents) {
        itemTotal = parseInt(item.properties._wc_price_override_cents) * item.quantity;
      }
      
      calculatedSubtotal += itemTotal;
      
      // Apply item discounts
      if (item.discounts) {
        item.discounts.forEach(discount => {
          calculatedDiscounts += discount.amount;
        });
      }
    });

    // Apply cart-level discounts
    if (this.cartData.cart_level_discount_applications) {
      this.cartData.cart_level_discount_applications.forEach(discount => {
        calculatedDiscounts += discount.total_allocated_amount;
      });
    }

    const expectedTotal = calculatedSubtotal - calculatedDiscounts;
    const actualTotal = this.cartData.total_price;
    
    // Allow small variance (1 cent) for rounding
    const variance = Math.abs(expectedTotal - actualTotal);
    
    if (variance > 1) {
      this.errors.push(`Total calculation mismatch: expected ${expectedTotal}c, got ${actualTotal}c (variance: ${variance}c)`);
    } else {
      console.log('[CV] ✓ Total calculation validated');
    }
  }

  showValidationResults() {
    console.log('[CV] Validation Results:');
    console.log(`[CV] Errors: ${this.errors.length}`);
    console.log(`[CV] Warnings: ${this.warnings.length}`);
    
    this.errors.forEach(error => console.error('[CV] ERROR:', error));
    this.warnings.forEach(warning => console.warn('[CV] WARNING:', warning));
    
    // Store results for checkout button validation
    window.checkoutValidation = {
      isValid: this.errors.length === 0,
      errors: this.errors,
      warnings: this.warnings,
      cartData: this.cartData
    };
  }

  setupValidation() {
    // Setup checkout button validation
    document.addEventListener('DOMContentLoaded', () => {
      this.validateCheckoutButtons();
    });

    // Setup AJAX cart update validation
    document.addEventListener('cart:updated', () => {
      setTimeout(() => this.loadCartData(), 500);
    });
  }

  validateCheckoutButtons() {
    const checkoutButtons = document.querySelectorAll('button[name="checkout"], .checkout-button, #checkout');
    
    checkoutButtons.forEach(button => {
      button.addEventListener('click', (event) => {
        if (!this.validateCheckout()) {
          event.preventDefault();
          event.stopPropagation();
          this.showCheckoutError();
          return false;
        }
        
        // Show confirmation for free gifts
        if (this.hasFreeGifts()) {
          event.preventDefault();
          event.stopPropagation();
          this.showFreeGiftConfirmation();
          return false;
        }
        
        return true;
      });
    });
  }

  validateCheckout() {
    if (!window.checkoutValidation) {
      console.warn('[CV] No validation data available');
      return true; // Allow checkout if no validation data
    }
    
    const { isValid, errors } = window.checkoutValidation;
    
    if (!isValid && errors.length > 0) {
      console.error('[CV] Checkout validation failed:', errors);
      return false;
    }
    
    return true;
  }

  hasFreeGifts() {
    if (!this.cartData) return false;
    
    return this.cartData.items.some(item => 
      item.properties && 
      (item.properties['Free Gift'] || 
       item.properties['free_gift'] ||
       item.properties['Is Free Gift'])
    );
  }

  showCheckoutError() {
    const errorMessage = `
      <div class="checkout-validation-error">
        <h3>Checkout Validation Error</h3>
        <p>There are issues with your cart that need to be resolved:</p>
        <ul>
          ${window.checkoutValidation.errors.map(error => `<li>${error}</li>`).join('')}
        </ul>
        <button onclick="this.parentElement.remove()">Close</button>
      </div>
    `;
    
    // Create modal or alert
    const modal = document.createElement('div');
    modal.innerHTML = errorMessage;
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 10000;
    `;
    
    document.body.appendChild(modal);
    
    // Auto-remove after 10 seconds
    setTimeout(() => {
      if (modal.parentElement) {
        modal.remove();
      }
    }, 10000);
  }

  showFreeGiftConfirmation() {
    const freeGifts = this.cartData.items.filter(item => 
      item.properties && 
      (item.properties['Free Gift'] || 
       item.properties['free_gift'] ||
       item.properties['Is Free Gift'])
    );
    
    const confirmationMessage = `
      <div class="free-gift-confirmation">
        <h3>Free Gift Confirmation</h3>
        <p>Your cart contains the following free gifts:</p>
        <ul>
          ${freeGifts.map(item => `<li>${item.product_title} - ${item.variant_title || 'Default'}</li>`).join('')}
        </ul>
        <p><strong>Free gifts will be automatically added to your order.</strong></p>
        <div style="margin-top: 20px;">
          <button onclick="this.closest('.free-gift-confirmation').parentElement.remove(); window.checkoutValidation.canProceed = true; document.querySelector('button[name=\\'checkout\\'], .checkout-button, #checkout')?.click();">Proceed to Checkout</button>
          <button onclick="this.closest('.free-gift-confirmation').parentElement.remove()">Cancel</button>
        </div>
      </div>
    `;
    
    const modal = document.createElement('div');
    modal.innerHTML = confirmationMessage;
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 10000;
    `;
    
    document.body.appendChild(modal);
  }
}

// Initialize checkout validator
document.addEventListener('DOMContentLoaded', () => {
  if (window.location.pathname === '/cart' || 
      window.location.pathname === '/cart/' ||
      document.querySelector('form[action="/cart"]')) {
    new CheckoutValidator();
  }
});