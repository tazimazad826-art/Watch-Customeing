

// let videoContainer = document.querySelectorAll('[id^="video-container-"]');

// videoContainer.forEach((videoItem) => {
//   if (videoItem.classList.contains("video-container")) {
//     let playButton = videoItem.querySelector(".play-button");
//     let video = videoItem.querySelector(".video");
//     if(!video) return;
//     videoItem.addEventListener("click", function () {
//       if (video.paused) {
//         video.play();
//         playButton.innerHTML = '<span class="pause-icon">'+DT_THEME.strings.pause+'</span>';
//       } else {
//         video.pause();
//         playButton.innerHTML = '<span class="play-icon">'+DT_THEME.strings.play+'</span>';
//       }
//     });
//     video.addEventListener("ended", function () {
//       playButton.innerHTML = '<span class="play-icon">'+DT_THEME.strings.play+'</span>';
//       playButton.style.opacity = "1";
//     });
//     videoItem.addEventListener("mousemove", function (event) {
//       const containerRect = videoItem.getBoundingClientRect();
//       const mouseX = event.clientX - containerRect.left;
//       const mouseY = event.clientY - containerRect.top;

//       const buttonWidth = playButton.offsetWidth;
//       const buttonHeight = playButton.offsetHeight;
//       const buttonX = mouseX - buttonWidth / 2;
//       const buttonY = mouseY - buttonHeight / 2;

//       const maxButtonX = containerRect.width - buttonWidth;
//       const maxButtonY = containerRect.height - buttonHeight;
//       playButton.style.left = Math.min(Math.max(buttonX, 0), maxButtonX) + "px";
//       playButton.style.top = Math.min(Math.max(buttonY, 0), maxButtonY) + "px";
//     });
//     videoItem.addEventListener("mouseleave", function () {
//       setTimeout(function () {
//         playButton.style.left = "50%";
//         playButton.style.top = "50%";
//         playButton.style.transform = "translate(-50%, -50%) scale(1)";
//         playButton.style.transition = "all 0.3s linear";
//       }, 50);
//     });
//     videoItem.addEventListener("mouseover", function () {
//       playButton.style.transition = "transform linear 0.3s";
//       playButton.style.transform = "scale(1.2)";
//     });
//   }
// });
