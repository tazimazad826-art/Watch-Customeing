// watch-configurator.js
// Version: 2025-01-23 18:30 - Made Option 4 (Case) work exactly like Option 1 by removing fallback images and ensuring proper metafield usage
console.log('[WC] Watch Configurator JavaScript file loaded successfully');

class WatchConfigurator {
  constructor(sectionId) {
    this.sectionId = sectionId;
    this.currentStep = 0;
    this.selections = {};
    this.totalPrice = 0;
    this.basePrice = 0; // Base product price in USD
    this.steps = [];
    this.stepOptions = {};
    this.stepOrder = ['model_type', 'movement', 'dial', 'hands', 'case', 'strap', 'strap_plus', 'rotor', 'personalization', 'summary'];
    this.optionalSteps = new Set(['strap', 'strap_plus', 'rotor', 'personalization', 'summary']);
    this.previewLayerOrder = ['movement', 'dial', 'hands', 'case', 'strap', 'strap_plus', 'rotor'];
    this.previewLayers = {};
    this.textPreviewLayer = null;
    this.configData = { steps: [] };
    this._configSignature = null;
    this.debug = {
      enabled: typeof window !== 'undefined' ? window.watchConfiguratorDebug !== false : false,
      log: (...args) => {
        if (this.debug.enabled) {
          console.log('[WC]', ...args);
        }
      }
    };
    // Fallback images removed - assuming metafields now provide proper preview images
    this.fallbackImages = {};
    this.init();
  }

  init() {
    console.log('[WC] WatchConfigurator init() called for section:', this.sectionId);
    this.getElements();
    console.log('[WC] Elements retrieved, container found:', !!this.container);

    // ALWAYS start clean — no stale selections masquerading as defaults
    this.selections = {};
    this.currentStep = 0;
    this.totalPrice = 0;
    // If you previously had loadSelectionsFromStorage(), DO NOT call it here.
    // Also clear any previous storage for this product to avoid confusion.
    try {
      const key = `watch-configurator-${window.productHandle || 'default'}`;
      localStorage.removeItem(key);
    } catch (e) {}

    if (this.container && !this.errorBar) {
      this.errorBar = document.createElement('div');
      this.errorBar.className = 'watch-configurator__error';
      this.errorBar.setAttribute('role', 'alert');
      this.errorBar.textContent = '';
      this.errorBar.classList.remove('is-visible');
      this.container.appendChild(this.errorBar);
    }

    console.log('[WC] window.watchConfigData available:', !!window.watchConfigData);
    const initialSource = window.watchConfigData?.custom_watch || window.watchConfigData;
    console.log('[WC] initialSource available:', !!initialSource);
    const initialConfig = this.hydrateFromMetafields(initialSource);
    console.log('[WC] initialConfig created, has steps:', !!(initialConfig?.steps));

    // Set base price from window.baseProductPrice (in USD)
    this.basePrice = window.baseProductPrice || 0;
    console.log('[WC] Base product price set to:', this.basePrice);

    this.applyConfigData(initialConfig);

    this.loadConfigData();
    this.setupEventListeners();
    this.setupMetafieldObserver();
    this.setupOptionClickListener();
    console.log('[WC] WatchConfigurator init() completed');
  }

  setupMetafieldObserver() {
    // Observe changes to metafield data (for dynamic updates)
    this.metafieldObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList' && mutation.target === document.head) {
          // Check if new script tags with metafield data were added
          const scripts = document.head.querySelectorAll('script');
          scripts.forEach(script => {
            if (script.textContent.includes('window.watchConfigData')) {
              this.reloadConfigData();
            }
          });
        }
      });
    });

    this.metafieldObserver.observe(document.head, {
      childList: true,
      subtree: true
    });

    // Also poll for metafield changes every 2 seconds as a fallback
    this.metafieldPollInterval = setInterval(() => {
      this.checkForMetafieldUpdates();
    }, 2000);

    // Listen for variant changes
    this.setupVariantChangeListener();
  }

  setupVariantChangeListener() {
    // Listen for Shopify variant change events
    document.addEventListener('variant:change', (event) => {
      const variant = event.detail.variant;
      if (variant && variant.id) {
        this.loadConfigDataForVariant(variant.id);
      }
    });

    // Also listen for form changes that might indicate variant selection
    const variantSelects = document.querySelectorAll('select[name="id"]');
    variantSelects.forEach(select => {
      select.addEventListener('change', (e) => {
        const variantId = e.target.value;
        if (variantId) {
          this.loadConfigDataForVariant(variantId);
        }
      });
    });
  }

  checkForMetafieldUpdates() {
    if (!window.watchConfigData) return;
    const source = window.watchConfigData.custom_watch || window.watchConfigData;
    const signature = JSON.stringify(this.hydrateFromMetafields(source));
    if (signature !== this._configSignature) {
      this.reloadConfigData();
    }
  }

  async reloadConfigData() {
    try {
      if (!window.watchConfigData) return;
      const source = window.watchConfigData.custom_watch || window.watchConfigData;
      const configData = this.hydrateFromMetafields(source);
      const signature = JSON.stringify(configData);

      if (signature === this._configSignature) {
        return;
      }

      this.applyConfigData(configData, { preserveSelections: true });
    } catch (error) {
      console.error('Error reloading configuration data:', error);
    }
  }

  getElements() {
    this.container = document.getElementById(`watch-configurator-${this.sectionId}`);
    this.stepsContainer = document.getElementById('configurator-steps');
    this.progressBar = document.getElementById('progress-bar');
    this.progressSteps = document.getElementById('progress-steps');
    this.previewContainer = document.getElementById('watch-preview');
    this.previewTitle = document.getElementById('preview-title');
    this.previewPrice = document.getElementById('preview-price');
    this.previewDetails = document.getElementById('preview-details');
    this.prevBtn = document.getElementById('prev-btn');
    this.nextBtn = document.getElementById('next-btn');
    this.errorBar = this.container?.querySelector('.watch-configurator__error') || null;
    this.addToCartBtn = document.getElementById('add-to-cart-btn');
  }
  hydrateFromMetafields(source) {
    const rawSource = source || window.watchConfigData || {};
    const base = rawSource?.custom_watch && typeof rawSource.custom_watch === 'object'
      ? rawSource.custom_watch
      : rawSource;
    const normalizedSource = this.normalizeMetafieldSource(base);

    const toArray = (value) => {
      if (!value) return [];
      if (Array.isArray(value)) return value;
      if (typeof value === 'object') {
        if (Array.isArray(value.options)) return value.options;
        return Object.values(value);
      }
      return [];
    };

    const norm = (arr = [], stepId) => toArray(arr)
      .map((option, index) => {
        if (!option || typeof option !== 'object') return null;
        const rawId = (option.id || option.handle || option.name || '').toString()
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-+|-+$/g, '');
        const fallbackId = `${stepId || 'option'}-${index}`;
        const id = rawId || fallbackId;
        const previewImage = option.preview_image || option.preview || option.image || '';
        const name = option.name || '';

        // Generate unique fallback image if no preview image provided
        const fallbackImage = previewImage || `https://via.placeholder.com/200x150?text=${encodeURIComponent(name)}`;

        return {
          id,
          name,
          price: Number(option.price || 0),
          description: option.description || '',
          preview_image: fallbackImage,
          image: fallbackImage,
          compatibility: option.compatibility || {},
          swatch: option.swatch || option.color || ''
        };
      })
      .filter(Boolean);

    console.log('[WC] Raw normalizedSource.case:', normalizedSource.case);
    console.log('[WC] Type of normalizedSource.case:', typeof normalizedSource.case);

    // Debug: Check if case data is an array and inspect first few items
    if (Array.isArray(normalizedSource.case)) {
      console.log('[WC] Case array length:', normalizedSource.case.length);
      if (normalizedSource.case.length > 0) {
        console.log('[WC] First case item:', normalizedSource.case[0]);
        console.log('[WC] First case item preview_image:', normalizedSource.case[0].preview_image);
        console.log('[WC] First case item preview:', normalizedSource.case[0].preview);
        console.log('[WC] First case item image:', normalizedSource.case[0].image);
        console.log('[WC] First case item keys:', Object.keys(normalizedSource.case[0]));
        console.log('[WC] First case item full object:', JSON.stringify(normalizedSource.case[0], null, 2));
      }
    } else if (normalizedSource.case && typeof normalizedSource.case === 'object') {
      console.log('[WC] Case is object, keys:', Object.keys(normalizedSource.case));
      console.log('[WC] Case object:', normalizedSource.case);
    } else {
      console.warn('[WC] Case data is neither array nor object:', normalizedSource.case);
    }

    // Additional debug for all case items if array
    if (Array.isArray(normalizedSource.case) && normalizedSource.case.length > 0) {
      console.log('[WC] All case items image fields:');
      normalizedSource.case.forEach((item, index) => {
        console.log(`[WC] Case item ${index}:`, {
          id: item.id,
          name: item.name,
          preview_image: item.preview_image,
          preview: item.preview,
          image: item.image,
          hasAnyImage: !!(item.preview_image || item.preview || item.image)
        });
      });
    }

    this.stepOptions = {
      model_type: [
        { id: 'prebuilt', name: 'Pre-built Models', price: 0, description: 'Quick selection with minimal color variations' },
        { id: 'custom', name: 'Full Customization', price: 0, description: 'Complete 9-step customization process' }
      ],
      movement: norm(normalizedSource.movement, 'movement'),
      dial: norm(normalizedSource.dial, 'dial'),
      hands: norm(normalizedSource.hands, 'hands'),
      case: norm(normalizedSource.case, 'case'),
      strap: norm(normalizedSource.strap, 'strap'),
      strap_plus: norm(normalizedSource.strap_plus, 'strap_plus'),
      rotor: norm(normalizedSource.rotor, 'rotor'),
      personalization: []
    };

    console.log('[WC] Processed case options:', this.stepOptions.case);
    console.log('[WC] Case options length:', this.stepOptions.case.length);
    if (this.stepOptions.case.length > 0) {
      console.log('[WC] First processed case option:', this.stepOptions.case[0]);
      console.log('[WC] First processed case option image fields:', {
        preview_image: this.stepOptions.case[0].preview_image,
        image: this.stepOptions.case[0].image
      });
      console.log('[WC] All processed case options image fields:');
      this.stepOptions.case.forEach((option, index) => {
        console.log(`[WC] Processed case option ${index}:`, {
          id: option.id,
          name: option.name,
          preview_image: option.preview_image,
          image: option.image,
          hasAnyImage: !!(option.preview_image || option.image),
          preview_imageValid: option.preview_image && option.preview_image.startsWith('http'),
          imageValid: option.image && option.image.startsWith('http')
        });
      });
    } else {
      console.error('[WC] No case options processed!');
    }

    this.debug?.log?.('mapped counts', {
      movement: this.stepOptions.movement.length,
      dial: this.stepOptions.dial.length,
      hands: this.stepOptions.hands.length,
      case: this.stepOptions.case.length,
      strap: this.stepOptions.strap.length
    });

    const steps = this.stepOrder.map((stepId) => {
      const baseStep = {
        id: stepId,
        title: this.getStepTitle(stepId),
        description: this.getStepDescription(stepId)
      };

      if (stepId === 'summary') {
        return baseStep;
      }

      return {
        ...baseStep,
        options: this.stepOptions[stepId] ? [...this.stepOptions[stepId]] : []
      };
    });

    return { steps };
  }

  normalizeMetafieldSource(source) {
    if (!source) return {};

    if (Array.isArray(source)) {
      return this.mapMetafieldsFromArray(source);
    }

    const normalized = {};

    if (typeof source === 'object') {
      Object.entries(source).forEach(([key, value]) => {
        if (key === 'custom_watch' && value && typeof value === 'object') {
          Object.assign(normalized, this.normalizeMetafieldSource(value));
          return;
        }

        if (key.startsWith('custom_watch.')) {
          const stepKey = this.normalizeStepKey(key.split('.')[1]);
          if (stepKey) {
            normalized[stepKey] = value;
          }
          return;
        }

        const normalizedKey = this.normalizeStepKey(key);
        if (this.stepOrder.includes(normalizedKey)) {
          normalized[normalizedKey] = value;
        }
      });
    }

    return normalized;
  }

  normalizeStepKey(key) {
    if (!key) return key;
    const map = {
      'extra-straps': 'strap_plus',
      'custom-rotor': 'rotor',
      'dial-personalization': 'personalization'
    };
    return map[key] || key;
  }

  mapMetafieldsFromArray(rawMetafields) {
    const mapped = {};

    rawMetafields.forEach((metafield) => {
      if (!metafield || metafield.namespace !== 'custom_watch') return;
      const key = this.normalizeStepKey(metafield.key);
      if (!key) return;

      let value = metafield.value;
      if (typeof value === 'string') {
        try {
          value = JSON.parse(value);
        } catch (error) {
          // Leave as-is if parsing fails
        }
      }

      mapped[key] = value;
    });

    return mapped;
  }

  normalizeStepOptions(stepId, rawStepData) {
    let optionsSource = [];

    if (Array.isArray(rawStepData)) {
      optionsSource = rawStepData;
    } else if (rawStepData && Array.isArray(rawStepData.options)) {
      optionsSource = rawStepData.options;
    } else if (rawStepData && typeof rawStepData === 'object') {
      optionsSource = Object.values(rawStepData);
    }

    return optionsSource
      .map((option, index) => this.normalizeOption(stepId, option, index))
      .filter(Boolean);
  }

  normalizeOption(stepId, option, index) {
    if (!option || typeof option !== 'object') return null;

    const fallbackId = `${stepId}-option-${index}`;
    const name = option.name || option.title || `Option ${index + 1}`;
    const previewImage = option.preview_image || option.image || option.img;

    // Generate unique fallback image if no preview image provided
    const fallbackImage = previewImage || `https://via.placeholder.com/200x150?text=${encodeURIComponent(name)}`;

    return {
      id: option.id || option.handle || (name ? name.toLowerCase().replace(/\s+/g, '-') : fallbackId) || fallbackId,
      name,
      price: Number(option.price) || 0,
      description: option.description || option.desc || '',
      preview_image: fallbackImage,
      image: fallbackImage,
      swatch: option.swatch || option.color || '',
      compatibility: option.compatibility || {}
    };
  }

  configHasOptions(configData) {
    return Boolean(
      configData?.steps?.some(
        (step) => step.id !== 'summary' && Array.isArray(step.options) && step.options.length > 0
      )
    );
  }

  extractCustomWatchMetafields(entity) {
    if (!entity) return {};

    if (Array.isArray(entity)) {
      return this.mapMetafieldsFromArray(entity);
    }

    if (entity.metafields) {
      if (Array.isArray(entity.metafields)) {
        return this.mapMetafieldsFromArray(entity.metafields);
      }
      if (typeof entity.metafields === 'object') {
        return this.normalizeMetafieldSource(entity.metafields);
      }
    }

    return this.normalizeMetafieldSource(entity);
  }

  applyConfigData(configData, { preserveSelections = false } = {}) {
    const safeConfig = configData && Array.isArray(configData.steps)
      ? configData
      : this.hydrateFromMetafields({});

    const previousSelections = preserveSelections ? { ...this.selections } : {};

    this.configData = safeConfig;
    this._configSignature = JSON.stringify(safeConfig);

    if (!preserveSelections) {
      this.selections = {};
      this.currentStep = 0;
    } else {
      const restoredSelections = {};
      safeConfig.steps.forEach((step) => {
        if (step.id === 'summary') return;
        const previous = previousSelections[step.id];
        if (!previous) return;
        const matchedOption = Array.isArray(step.options)
          ? step.options.find(option => option.id === previous.id)
          : null;
        if (matchedOption) {
          restoredSelections[step.id] = { ...matchedOption, stepId: step.id };
        }
      });

      if (previousSelections.personalization) {
        restoredSelections.personalization = { ...previousSelections.personalization };
      }

      this.selections = restoredSelections;
      this.currentStep = Math.min(this.currentStep, Math.max(safeConfig.steps.length - 1, 0));
    }

    this.totalPrice = 0;

    this.renderSteps();
    this.renderProgressSteps();
    this.ensurePreviewLayers();
    this.showStep(this.currentStep);
    this.updatePrice();
    this.updatePreview();
    this.updatePreviewDetails();
    this.updateNavigationButtons();
    this.updateCompatibleOptions();
  }

  markOptionSelected(stepId, optionId) {
    if (!this.stepsContainer) return;
    const stepElement = this.stepsContainer.querySelector(`[data-step-id="${stepId}"]`);
    if (!stepElement) return;

    const cards = stepElement.querySelectorAll('.watch-configurator__option');
    cards.forEach((card) => {
      const isSelected = card.dataset.optionId === optionId;
      card.classList.toggle('selected', isSelected);
      let indicator = card.querySelector('.selected-indicator');

      if (isSelected) {
        if (!indicator) {
          indicator = document.createElement('div');
          indicator.className = 'selected-indicator';
          indicator.innerHTML = '&#10003;';
          card.appendChild(indicator);
        }
      } else if (indicator) {
        indicator.remove();
      }
    });
  }

  clearDownstreamSelections(fromIndex) {
    if (!Array.isArray(this.configData?.steps)) return;

    const order = this.configData.steps.map((step) => step.id);
    for (let i = fromIndex + 1; i < order.length; i++) {
      const stepId = order[i];
      if (!stepId || stepId === 'summary') continue;

      delete this.selections[stepId];

      if (!this.stepsContainer) continue;
      const stepElement = this.stepsContainer.querySelector(`[data-step-id="${stepId}"]`);
      if (!stepElement) continue;

      stepElement.querySelectorAll('.watch-configurator__option').forEach((optionEl) => {
        optionEl.classList.remove('selected');
        optionEl.querySelector('.selected-indicator')?.remove();
      });

      if (stepId === 'personalization') {
        const input = stepElement.querySelector('[data-personalization-input]');
        if (input) {
          input.value = '';
        }
        const count = stepElement.querySelector('[data-personalization-count]');
        if (count) {
          count.textContent = '0';
        }
        // Clear uploaded image
        this.removeUploadedImage();
      }
    }
  }

  handlePersonalizationInput(inputEl) {
    const value = (inputEl.value || '').slice(0, 20);
    inputEl.value = value;

    const countEl = inputEl.closest('[data-personalization-wrapper]')?.querySelector('[data-personalization-count]');
    if (countEl) {
      countEl.textContent = String(value.length);
    }

    const p = this.selections['personalization'] || {};
    p.text = value.trim();
    p.image = this.uploadedImageData ? this.uploadedImageData.file : null;

    if (p.text || p.image) {
      this.selections['personalization'] = p;
      this.updatePersonalizationSelection();
    } else {
      delete this.selections['personalization'];
    }

    this.updatePrice();
    this.updatePreview();
    this.updatePreviewDetails();
    this.updateNavigationButtons();
    this.updateSummary();
  }
  updatePersonalizationSelection() {
    const p = this.selections['personalization'];
    if (!p) return;
    let parts = [];
    if (p.text && p.text.trim()) parts.push("Text: " + p.text.trim());
    if (p.image) parts.push("Image: " + p.image.name);
    p.value = parts.join(", ");
    p.name = 'Personalization';
    p.id = 'personalization';
    p.stepId = 'personalization';
    p.price = 75;
    if (!p.value) {
      delete this.selections['personalization'];
    }
  }

  syncPersonalizationState() {
    if (!this.stepsContainer) return;
    const stepElement = this.stepsContainer.querySelector('[data-step-id="personalization"]');
    if (!stepElement) return;

    const input = stepElement.querySelector('[data-personalization-input]');
    const count = stepElement.querySelector('[data-personalization-count]');
    const p = this.selections['personalization'];
    const textValue = p?.text || '';

    if (input) {
      input.value = textValue;
    }

    if (count) {
      count.textContent = String(textValue.length);
    }
  }

  getStepTitle(stepId) {
    const titles = {
      model_type: 'Choose Your Experience',
      movement: 'Movement',
      dial: 'Dial',
      hands: 'Hands',
      case: 'Case',
      strap: 'Strap',
      strap_plus: 'StrapPlus',
      rotor: 'Rotor',
      personalization: 'Personalization',
      summary: 'Summary'
    };
    return titles[stepId] || stepId;
  }

  getStepDescription(stepId) {
    const descriptions = {
      model_type: 'Select how you want to customize your watch',
      movement: 'Choose the heart of your timepiece',
      dial: 'Select the face of your watch',
      hands: 'Choose the style of your watch hands',
      case: 'Select the case that houses your movement',
      strap: 'Choose your main strap',
      strap_plus: 'Add additional straps to your collection',
      rotor: 'Personalize your watch rotor',
      personalization: 'Add a personal touch to your dial',
      summary: 'Review your custom watch configuration'
    };
    return descriptions[stepId] || '';
  }

  async loadConfigData() {
    try {
      let configData = null;

      if (window.watchConfigData) {
        const source = window.watchConfigData.custom_watch || window.watchConfigData;
        configData = this.hydrateFromMetafields(source);
      }

      if (!configData || !this.configHasOptions(configData)) {
        const productHandle = window.productHandle || 'your-custom-watch-handle';
        const response = await fetch(`/products/${productHandle}.json`);
        if (!response.ok) {
          throw new Error(`API fetch failed: ${response.status}`);
        }

        const data = await response.json();
        const productMetafields = this.extractCustomWatchMetafields(data.product);
        const hydrated = this.hydrateFromMetafields(productMetafields);

        if (!configData || this.configHasOptions(hydrated)) {
          configData = hydrated;
        }
      }

      this.applyConfigData(configData || this.hydrateFromMetafields({}));
    } catch (error) {
      console.error('Error loading configuration data:', error);
      this.showError('Metafields missing. Contact support.');
      this.applyConfigData(this.hydrateFromMetafields({}));
    }
  }

  async loadConfigDataForVariant(variantId) {
    try {
      const response = await fetch(`/variants/${variantId}.json`);
      if (!response.ok) {
        throw new Error(`Variant API fetch failed: ${response.status}`);
      }

      const data = await response.json();
      const variantMetafields = this.extractCustomWatchMetafields(data.variant);
      // No fallback needed - metafields should provide proper preview images
      const configData = this.hydrateFromMetafields(variantMetafields);

      if (!this.configHasOptions(configData)) {
        await this.loadConfigData();
        return;
      }

      this.applyConfigData(configData);
    } catch (error) {
      console.error('Error loading variant configuration data:', error);
      await this.loadConfigData();
    }
  }


  renderSteps() {
    if (!this.stepsContainer) return;
    this.stepsContainer.innerHTML = '';

    this.configData.steps.forEach((step, index) => {
      const stepElement = document.createElement('div');
      stepElement.className = `watch-configurator__step ${index === this.currentStep ? 'active' : ''}`;
      stepElement.dataset.stepId = step.id;

      if (step.id === 'summary') {
        stepElement.innerHTML = this.renderSummaryStep(step);
      } else if (step.id === 'personalization') {
      stepElement.innerHTML = this.renderDialPersonalizationStep(step);
    } else {
      stepElement.innerHTML = this.renderOptionsStep(step);
    }

      const optionsWrapper = stepElement.querySelector('.watch-configurator__options');
      if (optionsWrapper) {
        optionsWrapper.classList.remove('is-hidden');
      }

      this.stepsContainer.appendChild(stepElement);
    });

    this.restoreSelectedVisuals();
    this.syncPersonalizationState();
    this.updatePreview();
    this.updatePreviewDetails();
    this.updateNavigationButtons();
  }

  restoreSelectedVisuals() {
    if (!this.stepsContainer) return;

    Object.entries(this.selections).forEach(([stepId, option]) => {
      const optionSelector = `[data-step-id="${stepId}"] [data-option-id="${option.id}"]`;
      const optionEl = this.stepsContainer.querySelector(optionSelector);

      if (optionEl) {
        optionEl.classList.add('selected');

        if (!optionEl.querySelector('.selected-indicator')) {
          const indicator = document.createElement('div');
          indicator.className = 'selected-indicator';
          indicator.innerHTML = '&#10003;';
          optionEl.appendChild(indicator);
        }
      }
    });
  }

  renderOptionsStep(step) {
    const baseList = Array.isArray(step.options) ? step.options : [];
    this.debug?.log?.('render step', step.id, baseList.length);

    if (baseList.length === 0) {
      return `
        <h2 class="watch-configurator__step-title">${this.escapeHtml(step.title)}</h2>
        <p class="watch-configurator__step-description">${this.escapeHtml(step.description || '')}</p>
        <div class="watch-configurator__options">
          <div class="wc-empty">No options available for ${this.escapeHtml(step.id)}.</div>
        </div>
      `;
    }

    // Special handling for model_type step
    if (step.id === 'model_type') {
      return `
        <h2 class="watch-configurator__step-title">${this.escapeHtml(step.title)}</h2>
        <p class="watch-configurator__step-description">${this.escapeHtml(step.description || '')}</p>
        <div class="watch-configurator__model-type-options">
          ${baseList.map((option) => {
            const optionId = this.escapeHtml(option.id);
            const name = this.escapeHtml(option.name);
            const description = this.escapeHtml(option.description || '');

            return `
              <div class="watch-configurator__model-type-option" data-option-id="${optionId}">
                <div class="watch-configurator__model-type-name">${name}</div>
                <div class="watch-configurator__model-type-description">${description}</div>
              </div>
            `;
          }).join('')}
        </div>
      `;
    }

    const compatible = this.getCompatibleOptions(step);
    const options = compatible.length ? compatible : baseList;

    return `
      <h2 class="watch-configurator__step-title">${this.escapeHtml(step.title)}</h2>
      <p class="watch-configurator__step-description">${this.escapeHtml(step.description || '')}</p>
      <div class="watch-configurator__options">
        ${options.map((option) => {
          const optionId = this.escapeHtml(option.id);
          const name = this.escapeHtml(option.name);
          const description = this.escapeHtml(option.description || '');
          const imageSrc = this.escapeHtml(option.preview_image || option.preview || option.image || '');
          const swatch = option.swatch ? `<span class="watch-configurator__option-swatch" style="background:${this.escapeHtml(option.swatch)};"></span>` : '';
          const imageMarkup = imageSrc
            ? `<img src="${imageSrc}" alt="${name}" class="watch-configurator__option-image">`
            : '';

          return `
            <div class="watch-configurator__option" data-option-id="${optionId}">
              ${imageMarkup}
              <div class="watch-configurator__option-name">${name}</div>
              <div class="watch-configurator__option-price">+${this.formatPrice(option.price || 0)}</div>
              ${swatch}
              <div class="watch-configurator__option-description">${description}</div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  renderDialPersonalizationStep(step) {
    const selection = this.selections['personalization'] || {};
    const value = selection.value || '';
    const charCount = value.length;
    const inputId = `personalization-text-${this.sectionId}`;

    return `
      <h2 class="watch-configurator__step-title">${this.escapeHtml(step.title)}</h2>
      <p class="watch-configurator__step-description">${this.escapeHtml(step.description || '')}</p>
      <div class="watch-configurator__personalization" data-personalization-wrapper>
        <div class="watch-configurator__input-group">
          <label class="watch-configurator__label" for="${inputId}">
            Personalization Text
            <span class="watch-configurator__option-price">+${this.formatPrice(75)}</span>
          </label>
          <input
            type="text"
            id="${inputId}"
            class="watch-configurator__input"
            maxlength="20"
            data-personalization-input
            value="${this.escapeHtml(value)}"
            placeholder="e.g., Your Name, Special Date"
          >
          <div class="watch-configurator__character-count">
            <span data-personalization-count>${charCount}</span>/20 characters
          </div>
        </div>

        <!-- Image Upload Section -->
        <div class="watch-configurator__image-upload">
          <h4>Upload Custom Image (Optional)</h4>
          <p>Add a personal image to be engraved on your watch</p>
          <div class="watch-configurator__upload-area" id="upload-area">
            <input type="file" id="image-upload" accept="image/*" style="display: none;">
            <div class="watch-configurator__upload-placeholder">
              <div class="watch-configurator__upload-icon">📷</div>
              <div class="watch-configurator__upload-text">Click to upload image</div>
              <div class="watch-configurator__upload-hint">PNG, JPG up to 5MB</div>
            </div>
            <div class="watch-configurator__uploaded-image" id="uploaded-image" style="display: none;">
              <img id="preview-image" src="" alt="Uploaded image">
              <button type="button" class="watch-configurator__remove-image" id="remove-image">×</button>
            </div>
          </div>
        </div>

        <div class="watch-configurator__personalization-info">
          <p><strong>Personalization Guidelines:</strong></p>
          <ul>
            <li>Text will be placed at the 6 o'clock position</li>
            <li>Maximum 20 characters</li>
            <li>Additional 5-7 days for delivery</li>
            <li>Personalized items cannot be returned or exchanged</li>
          </ul>
        </div>
      </div>
    `;
  }

  renderSummaryStep(step) {
    return `
      <h2 class="watch-configurator__step-title">${this.escapeHtml(step.title)}</h2>
      <p class="watch-configurator__step-description">${this.escapeHtml(step.description || '')}</p>
      <div class="watch-configurator__summary">
        <h3 class="watch-configurator__summary-title">Configuration Details</h3>
        <div class="watch-configurator__summary-items" id="summary-items">
          <!-- Summary items will be dynamically loaded here -->
        </div>
        <div class="watch-configurator__summary-total">
          <span>Total:</span>
          <span id="summary-total">${this.formatPrice(this.totalPrice)}</span>
        </div>

        <button type="button" class="watch-configurator__btn watch-configurator__btn--primary watch-configurator__summary-btn" id="add-to-cart-btn">
          Add to Cart
        </button>
        <div class="watch-configurator__summary-delivery">
          <strong>Estimated Delivery:</strong> 2-4 weeks
        </div>
        <div class="watch-configurator__summary-guarantee">
          <strong>Quality Guarantee:</strong> 2-year warranty on all components
        </div>
      </div>
    `;
  }

  renderProgressSteps() {
    if (!this.progressSteps) return;
    this.progressSteps.innerHTML = '';
    
    this.configData.steps.forEach((step, index) => {
      if (step.id !== 'summary') {
        const stepElement = document.createElement('div');
        stepElement.className = 'watch-configurator__progress-step';
        stepElement.innerHTML = `
          <div class="watch-configurator__progress-step-number">${index + 1}</div>
          <div class="watch-configurator__progress-step-title">${this.escapeHtml(step.title)}</div>
        `;
        this.progressSteps.appendChild(stepElement);
      }
    });
  }

  getCompatibleOptions(step) {
    if (step.id === 'summary') return [];
    if (!Array.isArray(step.options)) return [];

    const stepIndex = this.getStepIndex(step.id);

    return step.options.filter((option) => this.isOptionSelectionCompatible(step.id, option, stepIndex));
  }

  showStep(stepIndex) {
    const stepsData = this.configData?.steps;
    if (!Array.isArray(stepsData) || !stepsData.length) {
      return;
    }

    // Update current step
    this.currentStep = stepIndex;

    // Update step visibility
    const steps = this.stepsContainer.querySelectorAll('.watch-configurator__step');
    steps.forEach((step, index) => {
      step.classList.toggle('active', index === stepIndex);
    });

    // Update progress bar - animate immediately to next step position
    const totalSteps = this.configData.steps.length - 1; // Exclude summary step
    const progressPercent = (stepIndex / totalSteps) * 100;
    if (this.progressBar) {
      // Set the new progress width immediately for instant animation
      this.progressBar.style.setProperty('--progress-width', `${progressPercent}%`);
    }

    if (this.progressSteps) {
      const progressStepElements = this.progressSteps.querySelectorAll('.watch-configurator__progress-step');
      progressStepElements.forEach((step, index) => {
        step.classList.toggle('active', index === stepIndex);
        step.classList.toggle('completed', index < stepIndex);
      });
    }

    const currentStep = stepsData[stepIndex];
    if (this.nextBtn && currentStep) {
      this.nextBtn.textContent = currentStep.id === 'summary' ? 'Add to Cart' : 'Next';
    }

    // Ensure selections are visually restored before updating controls or compatibility
    this.restoreSelectedVisuals();
    this.syncPersonalizationState();
    this.updateCompatibleOptions();
    this.updateNavigationButtons();
    this.updatePreview();
    this.updatePreviewDetails();

    // Always update summary when showing a step
    this.updateSummary();
  }



  getStepIndex(stepId) {
    if (!Array.isArray(this.configData?.steps)) return -1;
    return this.configData.steps.findIndex((step) => step.id === stepId);
  }



  isOptionSelectionCompatible(stepId, option) {
    if (!option) return false;

    if (option.compatibility) {
      for (const [relatedStepId, allowed] of Object.entries(option.compatibility)) {
        const selected = this.selections[relatedStepId];
        const allowedIds = Array.isArray(allowed) ? allowed : [allowed];
        if (selected && allowedIds.length && !allowedIds.includes(selected.id)) {
          return false;
        }
      }
    }

    for (const [otherStepId, selected] of Object.entries(this.selections)) {
      if (otherStepId === stepId || !selected.compatibility) continue;
      const allowed = selected.compatibility[stepId];
      const allowedIds = Array.isArray(allowed) ? allowed : (allowed ? [allowed] : []);
      if (allowedIds.length && !allowedIds.includes(option.id)) {
        return false;
      }
    }

    return true;
  }

  selectOption(stepId, optionId) {
    console.log(`[WC] selectOption called: stepId="${stepId}", optionId="${optionId}"`);

    const stepIndex = this.configData.steps.findIndex((s) => s.id === stepId);
    if (stepIndex === -1) {
      console.log('[WC] Step not found');
      return;
    }

    const step = this.configData.steps[stepIndex];
    const option = Array.isArray(step.options) ? step.options.find((o) => o.id === optionId) : null;
    if (!option) {
      console.log('[WC] Option not found');
      return;
    }

    console.log('[WC] Option found:', option);
    console.log('[SELECT DEBUG] Option price:', option.price, 'type:', typeof option.price);

    // Store selection for all step types including case
    this.selections[stepId] = { ...option, stepId };
    console.log('[SELECT DEBUG] Selection stored:', this.selections[stepId]);
    console.log('[SELECT DEBUG] All selections after storage:', this.selections);

    if (!this.isOptionSelectionCompatible(stepId, option)) {
      console.log('[WC] Option not compatible');
      return;
    }

    this.selections[stepId] = { ...option, stepId };
    console.log('[WC] Selection updated, current selections:', this.selections);

    // Special handling for model_type selection
    if (stepId === 'model_type') {
      this.handleModelTypeSelection(optionId);
      return;
    }

    // Special handling for prebuilt_models selection
    if (stepId === 'prebuilt_models') {
      this.markOptionSelected(stepId, optionId);
      this.updatePrice();
      this.updatePreview();
      this.updatePreviewDetails();
      this.updateNavigationButtons();
      return;
    }

    this.clearDownstreamSelections(stepIndex);

    this.markOptionSelected(stepId, optionId);
    this.updateCompatibleOptions();
    this.updatePrice();
    this.updatePreview();
    this.updatePreviewDetails();
    this.updateNavigationButtons();

    // Always update summary when selections change
    this.updateSummary();
  }

  updateCompatibleOptions() {
    if (!Array.isArray(this.configData?.steps) || !this.stepsContainer) return;

    for (let i = this.currentStep + 1; i < this.configData.steps.length; i++) {
      const step = this.configData.steps[i];
      if (!step || step.id === 'summary') continue;

      const stepElement = this.stepsContainer.querySelector(`[data-step-id="${step.id}"]`);
      if (!stepElement) continue;

      const optionsContainer = stepElement.querySelector('.watch-configurator__options');
      if (!optionsContainer) continue;

      const compatibleOptions = this.getCompatibleOptions(step);
      this.debug?.log?.('compatible', step.id, compatibleOptions.length);
      optionsContainer.classList.remove('is-hidden');

      if (!compatibleOptions.length) {
        optionsContainer.innerHTML = '<div class="wc-empty">No compatible options. Change your previous selection.</div>';
        delete this.selections[step.id];
        continue;
      }

      optionsContainer.innerHTML = compatibleOptions.map((option) => {
        const optionId = this.escapeHtml(option.id);
        const name = this.escapeHtml(option.name);
        const description = this.escapeHtml(option.description || '');
        const imageSrc = this.escapeHtml(option.preview_image || option.preview || option.image || '');
        const swatch = option.swatch ? `<span class="watch-configurator__option-swatch" style="background:${this.escapeHtml(option.swatch)};"></span>` : '';
        const imageMarkup = imageSrc
          ? `<img src="${imageSrc}" alt="${name}" class="watch-configurator__option-image">`
          : '';

        return `
          <div class="watch-configurator__option" data-option-id="${optionId}">
            ${imageMarkup}
            <div class="watch-configurator__option-name">${name}</div>
            <div class="watch-configurator__option-price">+${this.formatPrice(option.price || 0)}</div>
            ${swatch}
            <div class="watch-configurator__option-description">${description}</div>
          </div>
        `;
      }).join('');

      const savedSelection = this.selections[step.id];
      if (savedSelection) {
        const stillAvailable = compatibleOptions.some(option => option.id === savedSelection.id);
        if (stillAvailable) {
          const selectedEl = optionsContainer.querySelector(`[data-option-id="${savedSelection.id}"]`);
          if (selectedEl) {
            selectedEl.classList.add('selected');
            if (!selectedEl.querySelector('.selected-indicator')) {
              const indicator = document.createElement('div');
              indicator.className = 'selected-indicator';
              indicator.innerHTML = '&#10003;';
              selectedEl.appendChild(indicator);
            }
          }
        } else {
          delete this.selections[step.id];
        }
      }
    }

    this.updateNavigationButtons();
  }

  ensurePreviewLayers() {
    if (!this.previewContainer) return;

    this.previewLayerOrder.forEach((layerId, index) => {
      let layer = this.previewLayers[layerId];
      if (!layer) {
        layer = document.createElement('img');
        layer.className = `watch-configurator__preview-layer watch-configurator__preview-layer--${layerId}`;
        Object.assign(layer.style, {
          position: 'absolute',
          inset: '0',
          width: '100%',
          height: '100%',
          objectFit: 'contain',
          opacity: '0'
        });
        // Initialize the data attribute for tracking current source
        layer.dataset.currentSrc = '';
        this.previewContainer.appendChild(layer);
        this.previewLayers[layerId] = layer;
      }
      layer.style.zIndex = String(index + 1);
    });

    if (!this.textPreviewLayer) {
      this.textPreviewLayer = document.createElement('div');
      this.textPreviewLayer.className = 'watch-configurator__preview-text-layer';
      this.previewContainer.appendChild(this.textPreviewLayer);
    }
    this.textPreviewLayer.style.zIndex = String(this.previewLayerOrder.length + 1);
  }

  updateCasePreview(caseSelection) {
    console.log('[WC] updateCasePreview called - DEPRECATED: Case is now handled in updatePreview()');
    // Case is now handled in the general updatePreview method
    // This method is kept for backward compatibility but does nothing
  }

  updatePreview() {
    if (!this.previewContainer) return;

    console.log('[WC] updatePreview called, selections:', this.selections);
    console.log('[WC] Current case selection:', this.selections['case']);

    // Special handling for prebuilt models - show single preview image
    const prebuiltSelection = this.selections['prebuilt_models'];
    if (prebuiltSelection) {
      // Clear all existing layers
      this.previewLayerOrder.forEach((type) => {
        const layer = this.previewLayers[type];
        if (layer) {
          layer.style.opacity = '0';
          layer.dataset.currentSrc = '';
        }
      });

      // Show prebuilt model preview
      const prebuiltLayer = this.previewLayers['prebuilt'] || document.createElement('img');
      if (!this.previewLayers['prebuilt']) {
        prebuiltLayer.className = 'watch-configurator__preview-layer watch-configurator__preview-layer--prebuilt';
        Object.assign(prebuiltLayer.style, {
          position: 'absolute',
          inset: '0',
          width: '100%',
          height: '100%',
          objectFit: 'contain',
          opacity: '0'
        });
        prebuiltLayer.dataset.currentSrc = '';
        this.previewContainer.appendChild(prebuiltLayer);
        this.previewLayers['prebuilt'] = prebuiltLayer;
      }

      const src = prebuiltSelection.preview_image || prebuiltSelection.preview || prebuiltSelection.image || '';
      const finalSrc = src ? `${src}?t=${Date.now()}&prebuilt=${prebuiltSelection.id}` : '';

      if (finalSrc && prebuiltLayer.dataset.currentSrc !== finalSrc) {
        prebuiltLayer.src = finalSrc;
        prebuiltLayer.dataset.currentSrc = finalSrc;
        prebuiltLayer.alt = `Pre-built Model - ${prebuiltSelection.name}`;
        prebuiltLayer.style.opacity = '1';
      }

      // Hide text layer for prebuilt
      if (this.textPreviewLayer) {
        this.textPreviewLayer.style.opacity = '0';
      }

      this.updatePreviewDetails();
      return;
    }

    // Default behavior for custom configurations
    this.previewLayerOrder.forEach((type) => {
      const selection = this.selections[type];
      let img = this.previewLayers[type];

      if (!img) {
        img = document.createElement('img');
        img.className = `watch-configurator__preview-layer watch-configurator__preview-layer--${type}`;
        Object.assign(img.style, {
          position: 'absolute',
          inset: '0',
          width: '100%',
          height: '100%',
          objectFit: 'contain',
          opacity: '0'
        });
        // Store the current src in a data attribute for reliable comparison
        img.dataset.currentSrc = '';
        this.previewContainer.appendChild(img);
        this.previewLayers[type] = img;
        console.log(`[WC] Created new layer for ${type}`);
      }

      const src = selection?.preview_image || selection?.preview || selection?.image || '';
      const finalSrc = src ? `${src}?t=${Date.now()}&option=${selection.id}` : '';
      console.log(`[WC] Layer ${type}: hasSelection=${!!selection}, src="${src}", finalSrc="${finalSrc}", currentSrc="${img.dataset.currentSrc}"`);

      if (finalSrc) {
        // Always update the image source if it's different
        if (img.dataset.currentSrc !== finalSrc) {
          console.log(`[WC] Updating ${type} image from "${img.dataset.currentSrc}" to "${finalSrc}"`);
          img.src = finalSrc;
          img.dataset.currentSrc = finalSrc;
          img.alt = `${type} - ${selection?.name || ''}`.trim();
          img.onerror = () => {
            console.warn('[WC] Image load failed for', type, 'src:', finalSrc);
          };
          img.onload = () => {
            console.log(`[WC] Image loaded successfully for ${type}`);
          };
        }
        img.style.opacity = '1';
        console.log(`[WC] Set ${type} layer opacity to 1, z-index: ${img.style.zIndex}`);
      } else {
        img.style.opacity = '0';
        img.dataset.currentSrc = '';
        console.log(`[WC] Set ${type} layer opacity to 0 (no selection)`);
      }
    });

    // Special handling for case to ensure it updates properly
    console.log('[WC] Special case handling: ensuring case layer updates');
    const caseSelection = this.selections['case'];
    const caseLayer = this.previewLayers['case'];

    if (caseSelection && caseLayer) {
      const caseSrc = caseSelection.preview_image || caseSelection.preview || caseSelection.image || '';
      const caseFinalSrc = caseSrc ? `${caseSrc}?t=${Date.now()}&case=${caseSelection.id}` : '';

      if (caseFinalSrc && caseLayer.dataset.currentSrc !== caseFinalSrc) {
        console.log('[WC] Force updating case layer:', caseFinalSrc);
        caseLayer.src = caseFinalSrc;
        caseLayer.dataset.currentSrc = caseFinalSrc;
        caseLayer.style.opacity = '1';
        caseLayer.style.zIndex = '4'; // Proper layering order
      }
    } else if (caseLayer) {
      // Hide case layer if no case selection
      caseLayer.style.opacity = '0';
      caseLayer.dataset.currentSrc = '';
      console.log('[WC] No case selection, hiding case layer');
    }

    // Handle text preview layer for personalization
    if (!this.textPreviewLayer) {
      this.textPreviewLayer = document.createElement('div');
      this.textPreviewLayer.className = 'watch-configurator__preview-text-layer';
      this.previewContainer.appendChild(this.textPreviewLayer);
    }

    const personalization = this.selections['personalization'];
    if (personalization && personalization.value) {
      this.textPreviewLayer.textContent = personalization.value;
      this.textPreviewLayer.style.fontFamily = personalization.font || '';
      this.textPreviewLayer.style.opacity = '1';
    } else {
      this.textPreviewLayer.textContent = '';
      this.textPreviewLayer.style.fontFamily = '';
      this.textPreviewLayer.style.opacity = '0';
    }

    // Handle image preview layer for uploaded image
    if (!this.imagePreviewLayer) {
      this.imagePreviewLayer = document.createElement('img');
      this.imagePreviewLayer.className = 'watch-configurator__preview-image-layer';
      Object.assign(this.imagePreviewLayer.style, {
        position: 'absolute',
        inset: '0',
        width: '100%',
        height: '100%',
        objectFit: 'contain',
        opacity: '0',
        zIndex: String(this.previewLayerOrder.length + 2)
      });
      this.previewContainer.appendChild(this.imagePreviewLayer);
    }

    if (this.uploadedImageData && this.uploadedImageData.dataUrl) {
      this.imagePreviewLayer.src = this.uploadedImageData.dataUrl;
      this.imagePreviewLayer.style.opacity = '1';
    } else {
      this.imagePreviewLayer.style.opacity = '0';
    }

    this.updatePreviewDetails();
  }

  updatePreviewDetails() {
    if (!this.previewDetails) return;

    // Special handling for prebuilt models
    const prebuiltSelection = this.selections['prebuilt_models'];
    if (prebuiltSelection) {
      this.previewDetails.innerHTML = `<p class="watch-configurator__preview-detail-item">${this.escapeHtml(prebuiltSelection.description || prebuiltSelection.name)}</p>`;
      return;
    }

    const order = ['movement', 'dial', 'hands', 'case', 'strap', 'strap_plus', 'rotor', 'personalization'];
    const items = order
      .map((id) => {
        const selection = this.selections[id];
        if (!selection) return null;
        if (id === 'personalization' && selection.value) {
          return `${selection.name}: ${selection.value}`;
        }
        return selection.name;
      })
      .filter(Boolean);
    this.previewDetails.innerHTML = items.length
      ? items.map(text => `<p class="watch-configurator__preview-detail-item">${this.escapeHtml(text)}</p>`).join('')
      : '<p>Select components to see details</p>';
  }

  handleModelTypeSelection(modelType) {
    this.debug?.log?.('Model type selected:', modelType);

    if (modelType === 'prebuilt') {
      // For pre-built models, skip to a simplified selection
      this.showPrebuiltModels();
    } else if (modelType === 'custom') {
      // For full customization, proceed to next step
      this.showStep(1); // Go to movement step
    }

    this.updateNavigationButtons();
  }

  showPrebuiltModels() {
    // Create a simplified pre-built model selection step
    const prebuiltStep = {
      id: 'prebuilt_models',
      title: 'Choose Your Pre-built Model',
      description: 'Select from our curated collection of pre-configured watches',
      options: [
        {
          id: 'classic_black',
          name: 'Classic Black',
          price: 299,
          description: 'Timeless black dial with leather strap',
          preview_image: 'https://via.placeholder.com/400x400/000000/FFFFFF?text=Classic+Black'
        },
        {
          id: 'silver_modern',
          name: 'Silver Modern',
          price: 349,
          description: 'Clean silver design with metal bracelet',
          preview_image: 'https://via.placeholder.com/400x400/C0C0C0/000000?text=Silver+Modern'
        },
        {
          id: 'gold_elegant',
          name: 'Gold Elegant',
          price: 399,
          description: 'Luxurious gold accents with premium materials',
          preview_image: 'https://via.placeholder.com/400x400/GOLD/000000?text=Gold+Elegant'
        }
      ]
    };

    // Temporarily replace the current step with pre-built options
    const originalStep = this.configData.steps[this.currentStep];
    this.configData.steps[this.currentStep] = prebuiltStep;
    this.renderSteps();
    this.showStep(this.currentStep);
  }

  handleImageUpload(file) {
    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!allowedTypes.includes(file.type)) {
      this.showError('Please upload a PNG or JPG image.');
      return;
    }

    // Validate file size (5MB limit)
    const maxSize = 5 * 1024 * 1024; // 5MB in bytes
    if (file.size > maxSize) {
      this.showError('Image size must be less than 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const previewImage = document.getElementById('preview-image');
      const uploadedImage = document.getElementById('uploaded-image');
      const uploadArea = document.getElementById('upload-area');

      if (previewImage && uploadedImage && uploadArea) {
        previewImage.src = e.target.result;
        uploadedImage.style.display = 'block';
        uploadArea.querySelector('.watch-configurator__upload-placeholder').style.display = 'none';

        // Store the uploaded image data
        this.uploadedImageData = {
          file: file,
          dataUrl: e.target.result
        };

        // Update personalization selection to include image
        const p = this.selections['personalization'] || {};
        p.image = file;
        this.selections['personalization'] = p;
        this.updatePersonalizationSelection();

        // Update the preview to show the uploaded image
        this.updatePreview();
        this.updateSummary();
      }
    };
    reader.readAsDataURL(file);
  }

  removeUploadedImage() {
    const previewImage = document.getElementById('preview-image');
    const uploadedImage = document.getElementById('uploaded-image');
    const uploadArea = document.getElementById('upload-area');
    const imageInput = document.getElementById('image-upload');

    if (previewImage && uploadedImage && uploadArea && imageInput) {
      previewImage.src = '';
      uploadedImage.style.display = 'none';
      uploadArea.querySelector('.watch-configurator__upload-placeholder').style.display = 'flex';
      imageInput.value = '';

      // Clear stored image data
      this.uploadedImageData = null;

      // Update personalization selection to remove image
      const p = this.selections['personalization'];
      if (p) {
        p.image = null;
        this.updatePersonalizationSelection();
      }

      // Update the preview to hide the uploaded image
      this.updatePreview();
      this.updateSummary();
    }
  }

  updateMainContainer() {
    const container = this.container.querySelector('.watch-configurator__container');
    if (container) {
      // Update container classes based on current state
      container.classList.toggle('watch-configurator__container--has-selections', Object.keys(this.selections).length > 0);
      container.classList.toggle('watch-configurator__container--complete', this.isConfigurationComplete());
    }
  }

  isConfigurationComplete() {
    // Check if all required steps have selections
    const requiredSteps = ['movement', 'dial', 'hands', 'case', 'strap'];
    return requiredSteps.every(stepId => this.selections[stepId]);
  }

  updatePrice() {
    console.log('[PRICE DEBUG] updatePrice called');
    console.log('[PRICE DEBUG] current selections:', this.selections);
    console.log('[PRICE DEBUG] basePrice:', this.basePrice);
    console.log('[PRICE DEBUG] previewPrice element:', this.previewPrice);

    // Start with base product price
    this.totalPrice = this.basePrice;
    console.log('[PRICE DEBUG] Starting with base price:', this.totalPrice);

    // Special handling for prebuilt models - use only the prebuilt model price
    const prebuiltSelection = this.selections['prebuilt_models'];
    if (prebuiltSelection && prebuiltSelection.price) {
      console.log('[PRICE DEBUG] Using prebuilt model price:', prebuiltSelection.price);
      this.totalPrice = prebuiltSelection.price;
    } else {
      // Calculate total from all selected components for custom configurations
      console.log('[PRICE DEBUG] Calculating custom configuration prices');
      Object.values(this.selections).forEach(selection => {
        console.log('[PRICE DEBUG] processing selection:', selection.name, 'price:', selection.price, 'type:', typeof selection.price);
        if (selection.price && typeof selection.price === 'number') {
          this.totalPrice += selection.price;
          console.log('[PRICE DEBUG] added price, total now:', this.totalPrice);
        } else {
          console.log('[PRICE DEBUG] skipped selection - no valid price');
        }
      });
    }

    console.log('[PRICE DEBUG] final totalPrice:', this.totalPrice);

    // Update price display with animation
    const priceElement = this.previewPrice;
    const newPrice = this.formatPrice(this.totalPrice);
    console.log('[PRICE DEBUG] formatted price:', newPrice);

    if (priceElement && priceElement.textContent !== newPrice) {
      console.log('[PRICE DEBUG] updating price element');
      priceElement.style.transform = 'scale(1.1)';
      priceElement.style.transition = 'transform 0.2s ease';

      setTimeout(() => {
        priceElement.textContent = newPrice;
        priceElement.style.transform = 'scale(1)';
      }, 100);
    } else if (priceElement) {
      console.log('[PRICE DEBUG] price element text unchanged or element not found');
      priceElement.textContent = newPrice;
    } else {
      console.error('[PRICE DEBUG] priceElement not found!');
    }

    // Call updateMainProductPrice after updating internal price
    this.updateMainProductPrice();
  }

  updateMainProductPrice() {
    console.log('[PRICE DEBUG] updateMainProductPrice called, totalPrice:', this.totalPrice);
    // Don't update main product price for configurator - let cart handle pricing
    console.log('[PRICE DEBUG] Skipping main product price update for configurator');
  }

  updateSummary() {
    const summaryItems = document.getElementById('summary-items');
    const summaryTotal = document.getElementById('summary-total');
    if (!summaryItems || !summaryTotal) return;

    // Special handling for prebuilt models
    const prebuiltSelection = this.selections['prebuilt_models'];
    if (prebuiltSelection) {
      const itemHTML = `
        <div class="watch-configurator__summary-item">
          <span class="watch-configurator__summary-item-name">${this.escapeHtml(prebuiltSelection.name)}</span>
          <span class="watch-configurator__summary-item-price">${this.formatPrice(prebuiltSelection.price || 0)}</span>
        </div>
      `;
      summaryItems.innerHTML = itemHTML;

      // Add personalization to summary if present
      const personalization = this.selections['personalization'];
      if (personalization) {
        const personalizationItem = `
          <div class="watch-configurator__summary-item">
            <span class="watch-configurator__summary-item-name">${this.escapeHtml(personalization.name + ': ' + personalization.value)}</span>
            <span class="watch-configurator__summary-item-price">${this.formatPrice(personalization.price || 0)}</span>
          </div>
        `;
        summaryItems.innerHTML += personalizationItem;
      }

      summaryTotal.textContent = this.formatPrice(this.totalPrice);
      return;
    }

    // Default handling for custom configurations
    const itemsHTML = this.stepOrder
      .filter((stepId) => stepId !== 'summary' && stepId !== 'model_type')
      .map((stepId) => {
        const selection = this.selections[stepId];
        if (!selection) return '';
        const name =
          stepId === 'personalization' && selection.value
            ? `${selection.name}: ${selection.value}`
            : selection.name;
        return `
          <div class="watch-configurator__summary-item">
            <span class="watch-configurator__summary-item-name">${this.escapeHtml(name)}</span>
            <span class="watch-configurator__summary-item-price">${this.formatPrice(selection.price || 0)}</span>
          </div>
        `;
      })
      .join('');

    summaryItems.innerHTML = itemsHTML || '<p class="watch-configurator__summary-empty">No selections yet.</p>';
    summaryTotal.textContent = this.formatPrice(this.totalPrice);
  }

  formatPrice(usd) {
    // Get active currency from Shopify
    const activeCurrency = window.Shopify?.currency?.active || window.Shopify?.currency || document.documentElement?.getAttribute('data-shop-currency') || 'USD';

    if (activeCurrency === 'EUR') {
      // Convert USD to EUR (approximate rate: 1 USD = 0.85 EUR)
      const eurAmount = usd * 0.85;
      return new Intl.NumberFormat('de-DE', {
        style: 'currency',
        currency: 'EUR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(eurAmount);
    } else {
      // Default to USD
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(usd);
    }
  }

  escapeHtml(value) {
    if (value === undefined || value === null) return '';
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  showError(msg) {
    if (!this.errorBar) return;
    this.errorBar.textContent = msg || 'Please review your selection.';
    this.errorBar.classList.add('is-visible');
    clearTimeout(this._errT);
    this._errT = setTimeout(() => this.errorBar.classList.remove('is-visible'), 2500);
  }

  updateNavigationButtons() {
    const step = this.configData?.steps?.[this.currentStep];
    const stepId = step?.id;
    const isOptional = stepId ? this.optionalSteps.has(stepId) : false;
    const hasSelection = stepId === 'summary' ? true : isOptional || !!this.selections[stepId];

    // Special handling for prebuilt_models step - only show Back and Add to Cart buttons
    if (stepId === 'prebuilt_models') {
      if (this.nextBtn) {
        this.nextBtn.style.display = 'none';
      }
      if (this.addToCartBtn) {
        this.addToCartBtn.style.display = 'inline-block';
        // Enable/disable based on selection
        this.addToCartBtn.disabled = !this.selections['prebuilt_models'];
      }
      if (this.prevBtn) {
        this.prevBtn.disabled = false;
        this.prevBtn.style.display = 'inline-block';
      }
      return;
    }

    // Default behavior for other steps - allow skipping optional steps
    if (this.nextBtn) {
      this.nextBtn.style.display = 'inline-block';
      // For optional steps (7-9: strap_plus, rotor, personalization), always enable next button to allow skipping
      this.nextBtn.disabled = !hasSelection && stepId !== 'summary' && !isOptional;
    }
    if (this.addToCartBtn) {
      this.addToCartBtn.style.display = 'none';
    }
    if (this.prevBtn) {
      this.prevBtn.disabled = this.currentStep === 0;
      this.prevBtn.style.display = 'inline-block';
    }

    // Update next button text based on model type
    if (this.nextBtn && stepId === 'model_type') {
      const modelType = this.selections['model_type']?.id;
      if (modelType === 'prebuilt') {
        this.nextBtn.textContent = 'Continue to Pre-built Models';
      } else if (modelType === 'custom') {
        this.nextBtn.textContent = 'Start Customization';
      } else {
        this.nextBtn.textContent = 'Next';
      }
    }
  }

  setupEventListeners() {
    if (this.prevBtn) {
      this.prevBtn.addEventListener('click', () => {
        const step = this.configData?.steps?.[this.currentStep];
        const stepId = step?.id;

        // Special handling for prebuilt_models - go back to model_type selection
        if (stepId === 'prebuilt_models') {
          // Clear prebuilt selection and restore original model_type step
          delete this.selections['prebuilt_models'];
          // Restore the original model_type step that was replaced
          this.configData.steps[0] = {
            id: 'model_type',
            title: 'Choose Your Experience',
            description: 'Select how you want to customize your watch',
            options: [
              { id: 'prebuilt', name: 'Pre-built Models', price: 0, description: 'Quick selection with minimal color variations' },
              { id: 'custom', name: 'Full Customization', price: 0, description: 'Complete 9-step customization process' }
            ]
          };
          this.currentStep = 0;
          this.renderSteps();
          this.showStep(0);
          this.updatePrice();
          this.updatePreview();
          this.updatePreviewDetails();
          return;
        }

        if (this.currentStep > 0) {
          this.showStep(this.currentStep - 1);
        }
      });
    }

    if (this.nextBtn) {
      this.nextBtn.addEventListener('click', () => {
        const step = this.configData?.steps?.[this.currentStep];
        if (!step) return;
        const stepId = step.id;

        if (stepId !== 'summary' && this.nextBtn.disabled) {
          this.showError('Please select an option to continue.');
          return;
        }

        if (stepId === 'summary') {
          this.addToCart();
          return;
        }

        if (this.currentStep < this.configData.steps.length - 1) {
          this.showStep(this.currentStep + 1);
          // Scroll to top of page on next step
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      });
    }

    if (this.container) {
      this.container.addEventListener('click', (event) => {
        const target = event.target;
        if (target && target.id === 'add-to-cart-btn') {
          event.preventDefault();
          this.addToCart();
        }
      });
    }

    // Add event listener for Add to Cart button in prebuilt mode
    if (this.addToCartBtn) {
      this.addToCartBtn.addEventListener('click', (event) => {
        event.preventDefault();
        this.addToCart();
      });
    }
  }

  setupOptionClickListener() {
    if (!this.stepsContainer) return;

    this.stepsContainer.addEventListener('click', (event) => {
      const option = event.target.closest('.watch-configurator__option, .watch-configurator__model-type-option');
      if (!option) return;

      const stepElement = option.closest('[data-step-id]');
      const stepId = stepElement?.dataset.stepId;
      if (!stepId || stepId === 'summary') return;

      event.preventDefault();
      this.selectOption(stepId, option.dataset.optionId);
    });

    this.stepsContainer.addEventListener('input', (event) => {
      if (event.target.matches('[data-personalization-input]')) {
        this.handlePersonalizationInput(event.target);
      }
    });

    // Image upload functionality
    const uploadArea = document.getElementById('upload-area');
    const imageInput = document.getElementById('image-upload');
    const uploadedImage = document.getElementById('uploaded-image');
    const previewImage = document.getElementById('preview-image');
    const removeImage = document.getElementById('remove-image');

    if (uploadArea && imageInput) {
      uploadArea.addEventListener('click', () => {
        imageInput.click();
      });

      imageInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
          this.handleImageUpload(file);
        }
      });
    }

    if (removeImage) {
      removeImage.addEventListener('click', () => {
        this.removeUploadedImage();
      });
    }
  }

  async addToCart() {
    try {
      this.showError(''); // Clear any previous errors

      // Try multiple methods to find a valid variant ID
      const formVariant = document.querySelector('form[action*="/cart/add"] [name="id"]')?.value;
      const liquidVariant = window.selectedVariantId;

      // Try to get variant from product handle
      const byHandle = async () => {
        if (!window.productHandle) return null;
        try {
          const res = await fetch(`/products/${window.productHandle}.js`);
          if (!res.ok) {
            throw new Error(`Product fetch failed: ${res.status}`);
          }
          const pdata = await res.json();
          const v = (pdata.variants || []).find(v => v.available) || pdata.variants?.[0];
          return v ? v.id : null;
        } catch (error) {
          console.error('Error fetching product by handle:', error);
          return null;
        }
      };

      const resolvedVariantId = formVariant || liquidVariant || await byHandle();

      if (!resolvedVariantId) {
        this.showError('Unable to find a valid product variant. Please ensure a "Cart product" is assigned in the Theme Editor or contact support.');
        return;
      }

      // Prepare properties based on selection type
      const properties = {};
      const totalPriceCents = Math.max(0, Math.round(this.totalPrice * 100)); // Convert to cents
      const totalPriceString = (totalPriceCents / 100).toFixed(2);
      const activeCurrency = window.Shopify?.currency?.active || window.Shopify?.currency || document.documentElement?.getAttribute('data-shop-currency') || 'USD';
      properties['TotalPriceUSD'] = totalPriceCents.toString();

      const prebuiltSelection = this.selections['prebuilt_models'];
      if (prebuiltSelection) {
        // For prebuilt models, include the model details
        properties['Pre-built Model'] = prebuiltSelection.name;
        properties['Model Description'] = prebuiltSelection.description;
      } else {
        // For custom configurations, include specific component selections
        if (this.selections['dial']) {
          properties['Dial'] = this.selections['dial'].name;
        }
        if (this.selections['hands']) {
          properties['Hands'] = this.selections['hands'].name;
        }
        if (this.selections['case']) {
          properties['Case'] = this.selections['case'].name;
        }
        if (this.selections['strap']) {
          properties['Bracelet / Strap'] = this.selections['strap'].name;
        }
        if (this.selections['strap_plus']) {
          properties['Extra Straps'] = this.selections['strap_plus'].name;
        }
        if (this.selections['rotor']) {
          properties['Rotor'] = this.selections['rotor'].name;
        }
        if (this.selections['personalization']) {
          if (this.selections['personalization'].text) {
            properties['Personalization Text'] = this.selections['personalization'].text;
          }
          if (this.uploadedImageData && this.uploadedImageData.file) {
            properties['Personalization Image'] = this.uploadedImageData.file.name;
          }
        }
      }

      properties['ConfigSummary'] = JSON.stringify(this.selections);

      if (totalPriceCents > 0) {
        properties['Configured Total'] = `${totalPriceString} ${activeCurrency}`;
        properties['__wc_price_override_cents'] = totalPriceCents.toString();
        properties['__wc_price_override_currency'] = activeCurrency;
        properties['__wc_price_override_source'] = 'watch-configurator';
      } else {
        properties['Configured Total'] = `0.00 ${activeCurrency}`;
        properties['__wc_price_override_cents'] = '0';
        properties['__wc_price_override_currency'] = activeCurrency;
        properties['__wc_price_override_source'] = 'watch-configurator';
      }

      const payload = {
        items: [{
          id: resolvedVariantId,
          quantity: 1,
          properties
        }]
      };

      console.log('[CART DEBUG] Sending payload to cart:', payload);

      const response = await fetch('/cart/add.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(payload)
      });

      console.log('[CART DEBUG] Cart response status:', response.status);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('[CART DEBUG] Cart add failed:', errorData);
        throw new Error(errorData.description || `Cart add failed: ${response.status}`);
      }

      const result = await response.json();
      console.log('[CART DEBUG] Cart add result:', result);

      if (result.errors) {
        console.error('[CART DEBUG] Cart errors:', result.errors);
        throw new Error(result.errors.join(', '));
      }

      console.log('[CART DEBUG] Cart add successful, redirecting to cart');
      // Success - redirect to cart
      window.location.href = '/cart';
    } catch (error) {
      console.error('Add to cart error:', error);
      this.showError(`Failed to add to cart: ${error.message}. Please try again or contact support.`);
    }
  }

}

// Initialize configurator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  console.log('[WC] DOM Content Loaded - Looking for configurator sections');
  const configuratorSections = document.querySelectorAll('[id^="watch-configurator-"]');
  console.log('[WC] Found configurator sections:', configuratorSections.length);

  configuratorSections.forEach(section => {
    console.log('[WC] Initializing configurator for section:', section.id);
    const sectionId = section.id.replace('watch-configurator-', '');
    const instance = new WatchConfigurator(sectionId);
    window.watchConfigurators = window.watchConfigurators || [];
    window.watchConfigurators.push(instance);
    if (!window.watchConfigurator) {
      window.watchConfigurator = instance;
    }
    console.log('[WC] Configurator instance created for section:', sectionId);
  });
});
