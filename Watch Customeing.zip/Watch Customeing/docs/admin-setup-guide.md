# Watch Configurator Admin Setup Guide

## Overview
This guide provides step-by-step instructions for setting up the Watch Configurator system in Shopify, including metafield configuration and template assignment.

## Table of Contents
1. [Metafield Setup](#metafield-setup)
2. [Template Assignment](#template-assignment)
3. [Product Configuration](#product-configuration)
4. [Testing and Validation](#testing-and-validation)
5. [Troubleshooting](#troubleshooting)

---

## Metafield Setup

### Required Metafields
The watch configurator requires the following metafields to be populated for each product variant:

#### Namespace: `custom_watch`

| Metafield Key | Type | Description | Required |
|---------------|------|-------------|----------|
| `movement` | JSON | Available movement options | ✅ Yes |
| `dial` | JSON | Available dial options | ✅ Yes |
| `hands` | JSON | Available hands options | ✅ Yes |
| `case` | JSON | Available case options | ✅ Yes |
| `strap` | JSON | Available strap options | ✅ Yes |
| `strap_plus` | JSON | Additional strap options | ❌ Optional |
| `rotor` | JSON | Custom rotor options | ❌ Optional |
| `personalization` | JSON | Personalization options | ❌ Optional |
| `summary` | JSON | Configuration summary | ❌ Optional |

### Metafield JSON Structure

Each metafield should contain a JSON array of options. Here's the expected structure:

```json
{
  "options": [
    {
      "id": "unique-option-id",
      "name": "Option Display Name",
      "price": 0,
      "description": "Detailed description",
      "preview_image": "https://example.com/image.jpg",
      "swatch": "#000000",
      "compatibility": {
        "dial": ["compatible-dial-id"],
        "case": ["compatible-case-id"]
      }
    }
  ]
}
```

### Step-by-Step Metafield Setup

#### Step 1: Access Metafields
1. Go to **Admin Panel** → **Settings** → **Metafields**
2. Click on **Products** to configure product metafields
3. Add a new metafield or edit existing ones

#### Step 2: Create Metafields
For each required metafield:

1. **Name**: Use the exact key name (e.g., `movement`, `dial`)
2. **Namespace and key**: `custom_watch.movement` (for example)
3. **Type**: Select "JSON" from the dropdown
4. **Description**: Add helpful description for content editors
5. **Validation**: Set minimum/maximum if needed

#### Step 3: Populate Metafield Content
1. Click on a product that should have the configurator
2. Scroll down to the **Metafields** section
3. For each metafield, click **Add definition** if not already created
4. Input the JSON content for each metafield

#### Step 4: Example JSON Content

**Movement Metafield Example:**
```json
{
  "options": [
    {
      "id": "quartz-movement",
      "name": "Quartz Movement",
      "price": 0,
      "description": "Precise quartz movement with 2-year battery life",
      "preview_image": "https://example.com/quartz.jpg"
    },
    {
      "id": "automatic-movement",
      "name": "Automatic Movement",
      "price": 150,
      "description": "Swiss automatic movement with 40-hour power reserve",
      "preview_image": "https://example.com/automatic.jpg"
    }
  ]
}
```

**Dial Metafield Example:**
```json
{
  "options": [
    {
      "id": "black-dial",
      "name": "Black Dial",
      "price": 0,
      "description": "Classic black dial with white hour markers",
      "preview_image": "https://example.com/black-dial.jpg",
      "swatch": "#000000"
    },
    {
      "id": "white-dial",
      "name": "White Dial",
      "price": 25,
      "description": "Elegant white dial with black hour markers",
      "preview_image": "https://example.com/white-dial.jpg",
      "swatch": "#FFFFFF"
    }
  ]
}
```

---

## Template Assignment

### Watch Configurator Template
Products must be assigned to the special `watch-configurator` template to display the configurator interface.

#### Step 1: Create/Edit Template
1. Go to **Online Store** → **Themes**
2. Click **Actions** → **Edit code**
3. In the **Templates** directory, look for `watch-configurator.liquid`
4. If not exists, create a new template file named `watch-configurator.liquid`

#### Step 2: Assign Template to Products

**Method 1: Individual Product Assignment**
1. Go to **Products** → **All Products**
2. Click on a product you want to configure
3. In the **Search engine listing preview** section, click **Edit website SEO**
4. Under **Template**, select `watch-configurator`
5. Click **Save**

**Method 2: Bulk Assignment**
1. Go to **Products** → **All Products**
2. Select multiple products using checkboxes
3. Click **Actions** → **Edit products**
4. In the **Template** dropdown, select `watch-configurator`
5. Click **Update**

**Method 3: Via Theme Settings (Recommended)**
1. Go to **Customize** (from theme editor)
2. Add a **Watch Configurator** section to the product page
3. Enable the configurator
4. Save and test

---

## Product Configuration

### Adding the Watch Configurator Section

#### Step 1: Access Theme Customizer
1. Go to **Online Store** → **Themes**
2. Click **Customize** on your active theme

#### Step 2: Add Watch Configurator Section
1. Click **Add section**
2. Search for "Watch Configurator"
3. Click on the Watch Configurator section to add it

#### Step 3: Configure Section Settings
- **Enable Watch Configurator**: ✅ Check this box
- **Section Title**: Customize the heading text
- **Primary Color**: Set brand colors
- **Secondary Color**: Set background colors
- **Accent Color**: Set highlight colors

#### Step 4: Position Section
- Drag the section to the desired position on the product page
- Typically placed after the product gallery and before add-to-cart

### Required Product Variants

#### Base Variant Setup
Each watch configurator product needs at least one variant:

1. **Go to the product page** → **Variants** section
2. **Add a variant** with these characteristics:
   - **Title**: "Custom Watch" or similar
   - **Price**: Set the base price (will be overridden by configurator)
   - **SKU**: Set appropriate SKU
   - **Inventory**: Set to track quantity or continue selling

#### Variant-Specific Metafields
You can also set variant-specific metafields that override product-level ones:

1. **Click on a variant**
2. **Add metafields** with the same namespace: `custom_watch`
3. **Populate with variant-specific content**

---

## Testing and Validation

### Pre-Launch Checklist

#### ✅ Metafield Validation
- [ ] All required metafields are populated
- [ ] JSON structure is valid (use JSON validators)
- [ ] Preview images are accessible
- [ ] Price values are numeric

#### ✅ Template Assignment
- [ ] Products are assigned to `watch-configurator` template
- [ ] Watch Configurator section is enabled
- [ ] Section is positioned correctly

#### ✅ Functionality Testing
- [ ] Configurator loads without errors
- [ ] Options can be selected in all steps
- [ ] Price calculation updates correctly
- [ ] Add to cart functionality works
- [ ] Cart displays configurator selections properly

### Testing Procedure

#### Test 1: Configurator Loading
1. Navigate to a product with configurator enabled
2. Verify the configurator section appears
3. Check browser console for JavaScript errors
4. Ensure all steps load with options

#### Test 2: Option Selection
1. Go through each configurator step
2. Select different options
3. Verify compatibility filtering works
4. Check that preview updates correctly

#### Test 3: Price Calculation
1. Select various combinations of options
2. Verify price updates in real-time
3. Check that final price is calculated correctly
4. Add product to cart and verify price transfer

#### Test 4: Cart Integration
1. Add configured product to cart
2. Navigate to cart page
3. Verify configurator selections are displayed
4. Check that configured price appears correctly

#### Test 5: Checkout Flow
1. Proceed to checkout with configured product
2. Verify price validation works
3. Check that discounts are applied correctly
4. Confirm free gifts handling (if applicable)

---

## Troubleshooting

### Common Issues and Solutions

#### Issue 1: Configurator Not Loading
**Symptoms**: No configurator interface appears
**Solutions**:
1. Check if template is assigned correctly
2. Verify Watch Configurator section is enabled
3. Check browser console for JavaScript errors
4. Ensure metafields are populated

#### Issue 2: No Options Displayed
**Symptoms**: Configurator loads but shows "No options available"
**Solutions**:
1. Verify metafield JSON structure is correct
2. Check that metafields contain proper data
3. Use JSON validators to check syntax
4. Ensure namespace is `custom_watch`

#### Issue 3: Price Not Calculating
**Symptoms**: Price stays at $0.00 or base price
**Solutions**:
1. Check that option objects have numeric `price` fields
2. Verify JavaScript console for errors
3. Ensure base product price is set
4. Check price formatting

#### Issue 4: Add to Cart Fails
**Symptoms**: Clicking add to cart does nothing or shows error
**Solutions**:
1. Check that product has at least one variant
2. Verify variant is in stock or allows backorders
3. Check JavaScript console for errors
4. Ensure price calculation is working

#### Issue 5: Cart Display Issues
**Symptoms**: Configurator selections not showing in cart
**Solutions**:
1. Verify cart page uses updated template
2. Check that properties are being saved correctly
3. Inspect cart item properties in admin
4. Clear browser cache and test

### Debug Tools

#### Browser Console Commands
Run these in browser console to debug:

```javascript
// Check if configurator is loaded
console.log(window.watchConfigurators);

// Check metafield data
console.log(window.watchConfigData);

// Check current selections
console.log(window.watchConfigurator.selections);

// Force reload configurator data
window.watchConfigurator.loadConfigData();
```

#### Admin Panel Inspections
1. **Product Metafields**: Admin → Products → Select Product → Metafields
2. **Cart Properties**: Admin → Orders → Select Order → Line Items
3. **Variant Data**: Check variant metafields in product admin

### Getting Help

If issues persist:
1. Check browser console for errors
2. Verify all setup steps were completed
3. Test with default/theme settings
4. Contact development team with:
   - Screenshot of issue
   - Browser console errors
   - Product URL
   - Steps to reproduce

---

## Summary

This setup ensures that:
- ✅ All product variants have properly populated metafields
- ✅ Products are assigned to the watch-configurator template
- ✅ The configurator system functions correctly
- ✅ Cart and checkout integration works properly
- ✅ Price calculations and validations are accurate

Regular testing and maintenance will ensure the system continues to work smoothly.