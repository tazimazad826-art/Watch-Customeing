# Watch Configurator End-to-End Testing Guide

## Overview
This guide provides comprehensive testing procedures to validate all aspects of the watch configurator system, from product configuration through checkout completion.

## Testing Environment Setup

### Prerequisites
- [ ] Watch configurator system is fully installed
- [ ] Admin setup guide has been completed
- [ ] Test products have been configured with metafields
- [ ] Browser developer tools are accessible

### Test Data Setup
Create test products with the following configurations:

#### Product A: Basic Configurator
- **Movement**: 2 options (Quartz: $0, Automatic: $150)
- **Dial**: 3 options (Black: $0, White: $25, Blue: $50)
- **Case**: 2 options (Steel: $0, Gold: $200)
- **Strap**: 2 options (Leather: $0, Metal: $75)

#### Product B: Premium Configurator
- **Movement**: 3 options with compatibility rules
- **Dial**: 4 options with personalization available
- **Case**: 3 options with visual previews
- **Strap**: 5 options including strap_plus
- **Rotor**: Custom rotor options
- **Personalization**: Text and image upload

---

## Phase 1: Product Page Testing

### Test 1.1: Configurator Loading
**Objective**: Verify configurator interface loads correctly

**Steps**:
1. Navigate to a product with configurator enabled
2. Scroll to Watch Configurator section
3. Verify section header displays "Customize Your Timepiece"
4. Check that progress bar appears
5. Verify first step (model type selection) is active

**Expected Results**:
- ✅ Configurator section visible
- ✅ No JavaScript errors in console
- ✅ Progress indicators work
- ✅ Step navigation functional

**Browser Console Commands**:
```javascript
// Verify configurator loaded
console.log('Configurators found:', window.watchConfigurators?.length);

// Check metafield data
console.log('Config data:', window.watchConfigData);
```

### Test 1.2: Variant Transfer Confirmation
**Objective**: Confirm selected variants transfer properly

**Steps**:
1. Open browser developer tools
2. Run: `window.confirmVariantTransfer()`
3. Check console output for variant ID
4. Verify variant-specific metafields load

**Expected Results**:
- ✅ Variant ID returned
- ✅ Console shows "Confirmed variant transfer"
- ✅ Variant-specific options display

### Test 1.3: Personalization Transfer Confirmation
**Objective**: Ensure personalization data transfers correctly

**Steps**:
1. Run: `window.confirmPersonalizationTransfer()`
2. Check for personalization metafield data
3. Verify personalization options are available

**Expected Results**:
- ✅ Personalization data detected
- ✅ Console shows personalization transfer confirmed
- ✅ Personalization step appears

### Test 1.4: Total Price Calculation
**Objective**: Validate real-time price calculations

**Steps**:
1. Select various option combinations
2. Monitor price display in preview panel
3. Run: `window.ensureTotalPriceCalculation()`
4. Verify price updates match calculations

**Expected Results**:
- ✅ Price updates in real-time
- ✅ Base price + option prices = total
- ✅ Price calculation function returns correct value

---

## Phase 2: Cart Page Testing

### Test 2.1: Configurator Properties Reading
**Objective**: Verify cart reads configurator selections

**Steps**:
1. Complete a watch configuration
2. Add to cart
3. Navigate to cart page
4. Inspect cart item details

**Expected Results**:
- ✅ Configuration details displayed
- ✅ Components listed (Movement, Dial, Case, etc.)
- ✅ Personalization details shown
- ✅ Debug info visible for troubleshooting

**CSS Classes to Verify**:
```css
.cart-configurator-components { /* Should be styled */ }
.cart-configurator-personalization { /* Should be styled */ }
```

### Test 2.2: Total Price Display
**Objective**: Confirm cart shows correct configured totals

**Steps**:
1. Add configured product to cart
2. Verify price in cart item line
3. Check order summary subtotal
4. Compare with configurator preview price

**Expected Results**:
- ✅ Cart item price matches configurator total
- ✅ Order summary shows correct subtotal
- ✅ No discrepancy between configurator and cart

### Test 2.3: Selected Variants Display
**Objective**: Validate variant information is clear

**Steps**:
1. Check variant title display
2. Verify configuration breakdown
3. Test with multiple products in cart

**Expected Results**:
- ✅ Variant information clear
- ✅ Configuration components grouped
- ✅ Easy to understand selections

### Test 2.4: Discounts and Free Gifts Display
**Objective**: Confirm discount and gift handling

**Steps**:
1. Apply discount code to cart with configured product
2. Add free gift items
3. Check order summary display

**Expected Results**:
- ✅ Discounts applied correctly
- ✅ Free gifts shown with $0 price
- ✅ Total calculation includes discounts
- ✅ Visual styling for discounts/gifts

---

## Phase 3: Checkout Validation Testing

### Test 3.1: Total Price Validation
**Objective**: Ensure checkout validates configured totals

**Steps**:
1. Add configured product to cart
2. Click "Proceed to Checkout"
3. Monitor checkout validation
4. Check for validation errors

**Expected Results**:
- ✅ No validation errors
- ✅ Total matches configurator price
- ✅ Validation script runs successfully

### Test 3.2: Discount Application Verification
**Objective**: Confirm discounts apply correctly in checkout

**Steps**:
1. Apply discount to cart
2. Proceed to checkout
3. Verify discount appears in totals
4. Test with multiple discount scenarios

**Expected Results**:
- ✅ Discounts apply before tax
- ✅ Final total reflects discount
- ✅ No calculation errors

### Test 3.3: Free Gift Confirmation
**Objective**: Validate free gift handling

**Steps**:
1. Add product with free gift
2. Proceed to checkout
3. Look for free gift confirmation modal
4. Test modal interactions

**Expected Results**:
- ✅ Free gift confirmation appears
- ✅ Confirmation modal displays gift details
- ✅ User can confirm or cancel
- ✅ Gift adds correctly to order

---

## Phase 4: Integration Testing

### Test 4.1: Cross-Page Data Persistence
**Objective**: Verify data persists through user journey

**Steps**:
1. Start configuration, save selections
2. Navigate away and return
3. Add to cart, check persistence
4. Test browser back/forward

**Expected Results**:
- ✅ Selections persist during session
- ✅ Cart maintains configuration data
- ✅ No data loss during navigation

### Test 4.2: Multi-Product Cart Testing
**Objective**: Test cart with multiple configured products

**Steps**:
1. Add 2-3 different configured products
2. Verify each shows correct configuration
3. Check total calculations
4. Test quantity updates

**Expected Results**:
- ✅ Each product shows its configuration
- ✅ Individual totals correct
- ✅ Grand total accurate
- ✅ Quantity changes maintain prices

### Test 4.3: Error Handling Testing
**Objective**: Verify graceful error handling

**Steps**:
1. Break metafield data (invalid JSON)
2. Test with empty product variants
3. Disable configurator section
4. Test network interruptions

**Expected Results**:
- ✅ Errors don't crash configurator
- ✅ Fallback options work
- ✅ User-friendly error messages
- ✅ System recovers gracefully

---

## Phase 5: Performance Testing

### Test 5.1: Load Time Testing
**Objective**: Ensure acceptable performance

**Steps**:
1. Test configurator load time
2. Measure option selection response
3. Check image loading performance
4. Monitor JavaScript execution time

**Performance Targets**:
- ⚡ Initial load: < 2 seconds
- ⚡ Step navigation: < 500ms
- ⚡ Price updates: < 200ms
- ⚡ Image loading: Progressive, < 3 seconds

### Test 5.2: Mobile Responsiveness
**Objective**: Verify mobile functionality

**Steps**:
1. Test on mobile devices
2. Verify touch interactions
3. Check mobile layout
4. Test mobile cart display

**Expected Results**:
- ✅ Mobile-optimized interface
- ✅ Touch-friendly controls
- ✅ Readable text and buttons
- ✅ Fast mobile performance

---

## Browser Compatibility Testing

### Test Browsers
- [ ] Chrome (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Edge (latest)
- [ ] Mobile Chrome
- [ ] Mobile Safari

### Test Scenarios Per Browser
1. **Basic Functionality**
   - Configurator loads
   - Options selectable
   - Price calculations work

2. **Cart Integration**
   - Add to cart works
   - Cart displays correctly
   - Checkout process works

3. **JavaScript Features**
   - Modern JS features supported
   - No console errors
   - Responsive design

---

## Automated Testing Scripts

### Browser Console Test Suite
```javascript
// Run this in browser console for automated testing
const testSuite = {
  testConfigurator: () => {
    console.log('Testing configurator...');
    return window.watchConfigurator !== undefined;
  },
  
  testPriceCalculation: () => {
    console.log('Testing price calculation...');
    const total = window.ensureTotalPriceCalculation();
    return typeof total === 'number' && total >= 0;
  },
  
  testMetafieldData: () => {
    console.log('Testing metafield data...');
    return window.watchConfigData !== null;
  }
};

// Run all tests
Object.values(testSuite).forEach(test => {
  const result = test();
  console.log(`Test result: ${result ? 'PASS' : 'FAIL'}`);
});
```

---

## Test Results Documentation

### Test Result Template
```
## Test Case: [Name]
**Date**: [Date]
**Tester**: [Name]
**Browser**: [Browser/Version]

**Steps Performed**:
1. [Step 1]
2. [Step 2]
3. [Step 3]

**Expected Results**:
- [Expected result 1]
- [Expected result 2]

**Actual Results**:
- [Actual result 1]
- [Actual result 2]

**Status**: ✅ PASS / ❌ FAIL

**Notes**: [Any additional observations]
```

---

## Summary Checklist

### ✅ Product Page
- [ ] Variant transfer confirmed
- [ ] Personalization transfer confirmed  
- [ ] Total price calculation working
- [ ] All options selectable
- [ ] Preview updates correctly

### ✅ Cart Page
- [ ] Configurator properties read correctly
- [ ] Total price displays properly
- [ ] Selected variants clear
- [ ] Discounts/free gifts handled
- [ ] Visual styling applied

### ✅ Checkout Page
- [ ] Total validation working
- [ ] Discounts apply correctly
- [ ] Free gift confirmation works
- [ ] Validation errors handled

### ✅ Integration
- [ ] Data persistence working
- [ ] Multi-product support
- [ ] Error handling robust
- [ ] Performance acceptable
- [ ] Mobile responsive

---

## Troubleshooting Test Failures

### Common Test Failures and Solutions

**Issue**: Configurator not loading
**Solution**: Check template assignment and section enablement

**Issue**: Price calculation incorrect
**Solution**: Verify option price fields are numeric

**Issue**: Cart not showing selections
**Solution**: Check cart template update and property saving

**Issue**: Checkout validation failing
**Solution**: Verify checkout-validator.js is loaded

**Issue**: Mobile display problems
**Solution**: Check responsive CSS and viewport settings

---

This comprehensive testing ensures the watch configurator system works flawlessly across all user touchpoints and provides a smooth customer experience.